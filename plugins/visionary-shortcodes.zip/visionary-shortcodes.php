<?php
/**
Plugin Name: Visionary Shortcodes
Plugin URI: http://pixelthemestudio.ca
Description: Add all the required shortcodes for the theme
Version: 1.0.0
Author: Matt
Author URI: http://www.pixelthemestudio.ca
License: GPL3
**/

/* Contact */
function contact_form( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'email'      => '',
    ), $atts));

    $out = pts_contact_form($email);

    return $out;
}
add_shortcode('contactform', 'contact_form');


/* Read More - Logo Text */
function pts_readmore_lt( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'link'      => '#',
    ), $atts));

    $out = "<a class=\"Logo-Text\" href=\"" .$link. "\">" .do_shortcode($content). "</a>";

    return $out;
}
add_shortcode('readmore_lt', 'pts_readmore_lt');

/* Read More - Logo-Button */
function pts_readmore_lb( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'link'      => '#',
    ), $atts));

    $out = "<a class=\"Logo-Button\" href=\"" .$link. "\">" .do_shortcode($content). "</a>";

    return $out;
}
add_shortcode('readmore_lb', 'pts_readmore_lb');

/* Read More - Border-Button */
function pts_readmore_bb( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'link'      => '#',
    ), $atts));

    $out = "<a class=\"Border-Button\" href=\"" .$link. "\">" .do_shortcode($content). "</a>";

    return $out;
}
add_shortcode('readmore_bb', 'pts_readmore_bb');

/* Read More - Light-Button */
function pts_readmore_lib( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'link'      => '#',
    ), $atts));

    $out = "<a class=\"Light-Button\" href=\"" .$link. "\">" .do_shortcode($content). "</a>";

    return $out;
}
add_shortcode('readmore_lib', 'pts_readmore_lib');

/* Read More - Dark-Button */
function pts_readmore_db( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'link'      => '#',
    ), $atts));

    $out = "<a class=\"Dark-Button\" href=\"" .$link. "\">" .do_shortcode($content). "</a>";

    return $out;
}
add_shortcode('readmore_db', 'pts_readmore_db');


/* Drop cap - Grey */
function pts_dropcapgrey( $atts, $content = null ) {
    return '<span class="dropcapgrey">' . do_shortcode($content) . '</span>';
}
add_shortcode('dropcapgrey', 'pts_dropcapgrey');

/* Drop cap - Plum */
function pts_dropcapplum( $atts, $content = null ) {
    return '<span class="dropcapplum">' . do_shortcode($content) . '</span>';
}
add_shortcode('dropcapplum', 'pts_dropcapplum');


/* List Styles */
add_shortcode('listdarkgrey', 'pts_listdarkgrey');
function pts_listdarktgrey( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="darkgrey">', do_shortcode($content));
    return $content;
}

add_shortcode('listlightgrey', 'pts_listlightgrey');
function pts_listlightgrey( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="lightgrey">', do_shortcode($content));
    return $content;
}

add_shortcode('listgreen', 'pts_listgreen');
function pts_listgreen( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="green">', do_shortcode($content));
    return $content;
}

add_shortcode('listplum', 'pts_listplum');
function pts_listplum( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="plum">', do_shortcode($content));
    return $content;
}

add_shortcode('listarrow', 'pts_listarrow');
function pts_listarrow( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="arrow">', do_shortcode($content));
    return $content;
}

add_shortcode('list_roman', 'pts_list_roman');
function pts_list_roman( $atts, $content = null ) {
    $content = str_replace('<ol>', '<ol class="roman">', do_shortcode($content));
    return $content;
}
add_shortcode('list_alpha', 'pts_list_alpha');

function pts_list_alpha( $atts, $content = null ) {
    $content = str_replace('<ol>', '<ol class="alpha">', do_shortcode($content));
    return $content;
}
add_shortcode('list_zero_decimal', 'pts_zero_decimal');

function pts_zero_decimal( $atts, $content = null ) {
    $content = str_replace('<ol>', '<ol class="zerodecimal">', do_shortcode($content));
    return $content;
}

/* Quote blockquote */
function pts_quote( $atts, $content = null ) {
    return '<blockquote>' . do_shortcode($content) . '</blockquote';
}
add_shortcode('quote', 'pts_quote');

/* Column 196 */
function pts_four( $atts, $content = null ) {
    return '<div class="four">' . do_shortcode($content) . '</div>';
}
add_shortcode('four', 'pts_four');

/* Column 280 */
function pts_three( $atts, $content = null ) {
    return '<div class="three">' . do_shortcode($content) . '</div>';
}
add_shortcode('three', 'pts_three');

/* Column 445 */
function pts_two( $atts, $content = null ) {
    return '<div class="two">' . do_shortcode($content) . '</div>';
}
add_shortcode('two', 'pts_two');

/* Column 940 */
function pts_one( $atts, $content = null ) {
    return '<div class="one">' . do_shortcode($content) . '</div>';
}
add_shortcode('one', 'pts_one');